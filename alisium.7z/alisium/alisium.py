import sys, os
from PySide6.QtWidgets import *
from PySide6.QtWebEngineWidgets import QWebEngineView
from PySide6.QtWebEngineCore import QWebEnginePage, QWebEngineProfile
from PySide6.QtCore import QUrl, Qt, QSize
from PySide6.QtGui import QPixmap, QIcon

class Browser(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Alisium")
        self.setGeometry(100, 100, 900, 600)
        self.webviews, self.buttons, self.actions = [], [], []
        self.active_index = -1

        central = QWidget()
        layout = QVBoxLayout(central)
        layout.setContentsMargins(0, 0, 0, 0)
        self.setCentralWidget(central)

        self.url_bar = QLineEdit()
        self.url_bar.returnPressed.connect(self.load_url)

        self.back = QPushButton("←")
        self.back.clicked.connect(self.go_back)
        self.forward = QPushButton("→")
        self.forward.clicked.connect(self.go_forward)
        self.refresh = QPushButton("⟳")
        self.refresh.clicked.connect(self.refresh_page)
        go = QPushButton("Go")
        go.clicked.connect(self.load_url)

        logo = QLabel()
        base = os.path.abspath(os.path.dirname(__file__))
        pix = QPixmap(os.path.join(base, "alisiumicon.png")).scaledToHeight(24)
        logo.setPixmap(pix)

        top = QToolBar()
        top.setMovable(False)
        top.setContextMenuPolicy(Qt.PreventContextMenu)
        for w in [logo, self.back, self.forward, self.refresh, self.url_bar, go]:
            top.addWidget(w)
        self.addToolBar(Qt.TopToolBarArea, top)

        self.webview_container = QWidget()
        self.webview_layout = QHBoxLayout(self.webview_container)
        self.webview_layout.setContentsMargins(0, 0, 0, 0)
        layout.addWidget(self.webview_container)

        bottom = QToolBar()
        bottom.setMovable(False)
        bottom.setContextMenuPolicy(Qt.PreventContextMenu)
        self.addToolBar(Qt.BottomToolBarArea, bottom)
        self.bottom_toolbar = bottom

        self.add_tab = QPushButton("+")
        self.add_tab.clicked.connect(lambda: self.create_tab("https://www.duckduckgo.com"))
        self.add_tab_action = bottom.addWidget(self.add_tab)

        self.create_tab("https://www.duckduckgo.com")

    def create_tab(self, url):
        profile = QWebEngineProfile.defaultProfile()
        page = QWebEnginePage(profile)
        view = QWebEngineView()
        view.setPage(page)
        view.load(QUrl(url))

        cookie_store = view.page().profile().cookieStore()
        cookie_store.cookieAdded.connect(lambda cookie:
            print(cookie.name().data().decode(), "=", cookie.value().data().decode())
        )
        self.webviews.append(view)

        button = QPushButton()
        button.setFixedSize(32, 28)
        button.setIconSize(QSize(16, 16))
        button.setCursor(Qt.PointingHandCursor)
        button.setFocusPolicy(Qt.NoFocus)

        idx = len(self.webviews) - 1
        action = self.bottom_toolbar.insertWidget(self.add_tab_action, button)
        self.actions.append(action)
        self.buttons.append(button)

        button.clicked.connect(lambda: self.switch_tab(idx))

        def update_icon():
            ico = view.icon()
            if not ico.isNull():
                button.setIcon(ico)

        view.iconChanged.connect(update_icon)

        def mouse_event(e, i=idx):
            if e.button() == Qt.RightButton:
                self.close_tab(i)
            else:
                QPushButton.mousePressEvent(button, e)

        button.mousePressEvent = lambda e, i=idx: mouse_event(e, i)

        self.switch_tab(idx)

    def close_tab(self, index):
        if len(self.webviews) <= 1:
            return
        self.bottom_toolbar.removeAction(self.actions[index])
        del self.actions[index]
        self.webviews[index].deleteLater()
        del self.webviews[index]
        del self.buttons[index]

        if self.active_index == index:
            self.active_index = max(0, index - 1)
            self.switch_tab(self.active_index)
        elif index < self.active_index:
            self.active_index -= 1

    def switch_tab(self, index):
        for i in reversed(range(self.webview_layout.count())):
            w = self.webview_layout.itemAt(i).widget()
            if w:
                w.setParent(None)
        self.active_index = index
        self.webview_layout.addWidget(self.webviews[index])
        self.url_bar.setText(self.webviews[index].url().toString())

    def load_url(self):
        if self.active_index != -1:
            url = self.url_bar.text()
            if not url.startswith("http"):
                url = "https://" + url
            self.webviews[self.active_index].load(QUrl(url))

    def go_back(self):
        if self.active_index != -1:
            self.webviews[self.active_index].back()

    def go_forward(self):
        if self.active_index != -1:
            self.webviews[self.active_index].forward()

    def refresh_page(self):
        if self.active_index != -1:
            self.webviews[self.active_index].reload()

if __name__ == "__main__":
    print("Alisium Browser")
    print("WARNING: DO NOT SHARE YOUR INTERNET COOKIES WITH ANYONE.")
    app = QApplication(sys.argv)
    app.setStyle("Fusion")
    browser = Browser()
    browser.show()
    sys.exit(app.exec())
